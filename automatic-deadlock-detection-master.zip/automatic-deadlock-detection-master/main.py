from src.gui import DeadlockApp

if __name__ == "__main__":
    app = DeadlockApp()
    app.run()
