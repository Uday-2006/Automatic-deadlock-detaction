import tkinter as tk
from src.logic import detect_deadlock

class DeadlockApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Automatic Deadlock Detection System")
        self.root.geometry("1000x700")

        self._build_ui()

    def _build_ui(self):
        # ---------- HEADER ----------
        header = tk.Frame(self.root, bg="#0f172a", height=60)
        header.pack(fill="x")

        title = tk.Label(
            header,
            text="Automatic Deadlock Detection System",
            bg="#0f172a",
            fg="white",
            font=("Segoe UI", 16, "bold")
        )
        title.pack(padx=20, pady=12, anchor="w")

        # STATUS BANNER (Commit 8)
        self.status_label = tk.Label(
            header,
            text="STATUS: READY",
            bg="#0f172a",
            fg="yellow",
            font=("Segoe UI", 12, "bold")
        )
        self.status_label.pack(side="right", padx=20)

        # ---------- MAIN AREA ----------
        container = tk.Frame(self.root)
        container.pack(fill="both", expand=True, padx=10, pady=10)

        # Left panel
        self.left_panel = tk.Frame(container, width=250)
        self.left_panel.pack(side="left", fill="y")

        tk.Label(self.left_panel, text="Number of Processes:", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.process_count = tk.IntVar(value=3)
        tk.Spinbox(self.left_panel, from_=1, to=20, textvariable=self.process_count, width=8).pack(anchor="w")

        tk.Label(self.left_panel, text="Number of Resources:", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 0))
        self.resource_count = tk.IntVar(value=2)
        tk.Spinbox(self.left_panel, from_=1, to=20, textvariable=self.resource_count, width=8).pack(anchor="w")

        tk.Button(
            self.left_panel,
            text="Generate Matrices",
            command=self._generate_matrices,
            bg="#1e293b",
            fg="white",
            width=18
        ).pack(pady=12)

        tk.Button(
            self.left_panel,
            text="Detect Deadlock",
            command=self._detect_deadlock,
            bg="#1e40af",
            fg="white",
            width=18
        ).pack(pady=6)

        # ---------- RIGHT PANEL (scrollable) ----------
        self.right_panel = tk.Frame(container)
        self.right_panel.pack(side="left", fill="both", expand=True)

        # Scrollable canvas
        self.matrix_canvas = tk.Canvas(self.right_panel, bg="white")
        self.v_scroll = tk.Scrollbar(self.right_panel, orient="vertical", command=self.matrix_canvas.yview)
        self.h_scroll = tk.Scrollbar(self.right_panel, orient="horizontal", command=self.matrix_canvas.xview)

        self.matrix_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)

        self.matrix_canvas.pack(side="left", fill="both", expand=True)
        self.v_scroll.pack(side="right", fill="y")
        self.h_scroll.pack(side="bottom", fill="x")

        self.matrix_inner = tk.Frame(self.matrix_canvas, bg="white")
        self.matrix_canvas.create_window((0, 0), window=self.matrix_inner, anchor="nw")

        # Auto update scroll region
        def _update_scroll(event):
            self.matrix_canvas.configure(scrollregion=self.matrix_canvas.bbox("all"))

        self.matrix_inner.bind("<Configure>", _update_scroll)

        # Touchpad + shift scroll
        self.matrix_canvas.bind("<MouseWheel>", lambda e: self.matrix_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
        self.matrix_canvas.bind("<Shift-MouseWheel>", lambda e: self.matrix_canvas.xview_scroll(int(-1*(e.delta/120)), "units"))

        # Result box
        self.result_box = tk.Text(self.right_panel, height=6, font=("Segoe UI", 10))
        self.result_box.pack(fill="x", pady=12)

    # ---------- MATRIX GENERATION ----------
    def _generate_matrices(self):
        for widget in self.matrix_inner.winfo_children():
            widget.destroy()

        n = self.process_count.get()
        m = self.resource_count.get()

        # Allocation
        tk.Label(self.matrix_inner, text="Allocation Matrix (A)", font=("Segoe UI", 12, "bold")).pack(pady=(10, 0))
        self.alloc_frame = tk.Frame(self.matrix_inner)
        self.alloc_frame.pack()

        self.alloc_entries = []
        for i in range(n):
            row = tk.Frame(self.alloc_frame)
            row.pack()
            row_entries = []
            for j in range(m):
                e = tk.Entry(row, width=5)
                e.insert(0, "0")
                e.pack(side="left", padx=3)
                row_entries.append(e)
            self.alloc_entries.append(row_entries)

        # Request
        tk.Label(self.matrix_inner, text="Request Matrix (R)", font=("Segoe UI", 12, "bold")).pack(pady=(12, 0))
        self.req_frame = tk.Frame(self.matrix_inner)
        self.req_frame.pack()

        self.req_entries = []
        for i in range(n):
            row = tk.Frame(self.req_frame)
            row.pack()
            row_entries = []
            for j in range(m):
                e = tk.Entry(row, width=5)
                e.insert(0, "0")
                e.pack(side="left", padx=3)
                row_entries.append(e)
            self.req_entries.append(row_entries)

        # Available
        tk.Label(self.matrix_inner, text="Available Vector (V)", font=("Segoe UI", 12, "bold")).pack(pady=(12, 0))
        self.avail_frame = tk.Frame(self.matrix_inner)
        self.avail_frame.pack()

        self.avail_entries = []
        for j in range(m):
            e = tk.Entry(self.avail_frame, width=5)
            e.insert(0, "0")
            e.pack(side="left", padx=3)
            self.avail_entries.append(e)

        self.matrix_canvas.update_idletasks()
        self.matrix_canvas.configure(scrollregion=self.matrix_canvas.bbox("all"))

    # ---------- READ MATRICES ----------
    def _read_matrices(self):
        n = len(self.alloc_entries)
        m = len(self.alloc_entries[0])

        allocation = []
        for i in range(n):
            allocation.append([int(e.get()) for e in self.alloc_entries[i]])

        request = []
        for i in range(n):
            request.append([int(e.get()) for e in self.req_entries[i]])

        available = [int(e.get()) for e in self.avail_entries]

        return allocation, request, available

    # ---------- DEADLOCK DETECTION + HIGHLIGHT ----------
    def _detect_deadlock(self):
        allocation, request, available = self._read_matrices()
        dead, proc = detect_deadlock(allocation, request, available)

        self.result_box.delete("1.0", "end")

        # Reset row colors
        for i in range(len(self.alloc_entries)):
            for e in self.alloc_entries[i]:
                e.config(bg="white")
            for e in self.req_entries[i]:
                e.config(bg="white")

        if dead:
            # Highlight rows
            for p in proc:
                for e in self.alloc_entries[p]:
                    e.config(bg="#ffcccc")
                for e in self.req_entries[p]:
                    e.config(bg="#ffcccc")

            self.result_box.insert("end", f"❌ DEADLOCK DETECTED — Processes: {proc}\n")

            self.status_label.config(text="STATUS: DEADLOCK DETECTED", fg="red")

        else:
            self.result_box.insert("end", "🟢 SAFE — No Deadlock Detected.\n")

            self.status_label.config(text="STATUS: SAFE", fg="lightgreen")

    def run(self):
        self.root.mainloop()
