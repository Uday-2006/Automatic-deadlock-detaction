def detect_deadlock(alloc, req, avail):
    n = len(alloc)     # number of processes
    m = len(avail)     # number of resource types

    # Work = Available initially
    work = avail.copy()
    finish = [False] * n

    changed = True
    while changed:
        changed = False
        for i in range(n):
            if not finish[i]:
                can_run = True
                for j in range(m):
                    if req[i][j] > work[j]:
                        can_run = False
                        break
                if can_run:
                    # This process can finish
                    for j in range(m):
                        work[j] += alloc[i][j]
                    finish[i] = True
                    changed = True

    # Deadlocked processes are those that never finished
    deadlocked = [i for i in range(n) if not finish[i]]

    return (len(deadlocked) > 0, deadlocked)
